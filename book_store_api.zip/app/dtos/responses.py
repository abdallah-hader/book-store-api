from datetime import datetime
from pydantic import BaseModel
from app.enums import OrderStatus, Role


class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    role: Role
    is_active: bool


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class AuthorSummaryResponse(BaseModel):
    id: int
    name: str


class BookSummaryResponse(BaseModel):
    id: int
    title: str


class AuthorProfileResponse(BaseModel):
    bio: str
    website: str | None


class AuthorResponse(BaseModel):
    id: int
    name: str
    email: str | None
    profile: AuthorProfileResponse | None
    books: list[BookSummaryResponse]


class AuthorListItemResponse(BaseModel):
    id: int
    name: str
    book_count: int


class GenreResponse(BaseModel):
    id: int
    name: str


class BookResponse(BaseModel):
    id: int
    title: str
    price: float
    stock: int
    author: AuthorSummaryResponse
    genres: list[GenreResponse]


class OrderResponse(BaseModel):
    id: int
    user_id: int
    book_id: int
    book_title: str
    book_author: str
    quantity: int
    total_price: float
    status: OrderStatus
    created_at: datetime